﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1.panels.extend_control
{
    /// <summary>
    /// TabViewPage.xaml 的交互逻辑
    /// </summary>
    public partial class TabViewPage : UserControl
    {
        public TabViewPage()
        {
            InitializeComponent();
        }

        public void AddTab(string title,UserControl addControl)
        {
            var item = new TabItemEx();
            item.Header = title;
            item.ToolTip = title;
            item.Margin = new Thickness(0, 0, 1, 0);
            item.Height = 28;
            StackPanel sPanel = new StackPanel();
            sPanel.Children.Add(addControl);
            item.Content = sPanel;
            tab_Main.Items.Add(item);
        }
    }
}
