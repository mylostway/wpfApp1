﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using WpfApp1.Base;

namespace WpfApp1.panels.main
{
    /// <summary>
    /// LeftMenu.xaml 的交互逻辑
    /// </summary>
    public partial class LeftMenu : UserControl
    {
        public LeftMenu()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 设置MenuItem鼠标单击事件
        /// </summary>
        /// <param name="handler"></param>
        public void SetMenuClickHandler(MouseButtonEventHandler handler)
        {
            if (null == handler) return;

            var uiCollections = this.menuRoot.Children;

            foreach (var e in uiCollections)
            {
                var tvi = e as TreeViewItem;
                if (null != tvi)
                {
                    tvi.MouseLeftButtonDown += handler;
                }
            }
        }





    }
}
