﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Base.Data
{
    public class MenuAttachedData
    {
        public MenuAttachedData() { ChildMenus = new List<MenuAttachedData>(); }

        /// <summary>
        /// 菜单名字
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 菜单图标地址
        /// </summary>
        public string IconUrl { get; set; }

        /// <summary>
        /// 菜单关联信息
        /// </summary>
        public string AttachedData { get; set; }

        /// <summary>
        /// 子菜单列表
        /// </summary>
        public List<MenuAttachedData> ChildMenus { get; set; }


    }
}
